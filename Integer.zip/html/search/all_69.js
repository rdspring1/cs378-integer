var searchData=
[
  ['integer',['Integer',['../classInteger.html',1,'Integer&lt; T, C &gt;'],['../classInteger.html#a1d5315e4ec5b56b8cb3a6991d514f7d6',1,'Integer::Integer(int value)'],['../classInteger.html#afebf72d47413ceedcc30b74c3055b771',1,'Integer::Integer(const std::string &amp;value)']]],
  ['integer_2eh',['Integer.h',['../Integer_8h.html',1,'']]],
  ['inverse_5fshift_5fleft_5fdigits',['inverse_shift_left_digits',['../Integer_8h.html#a256912b8b1003d57a93563ce2e8609f7',1,'Integer.h']]]
];
