var searchData=
[
  ['resize',['resize',['../classInteger.html#a867b7d41eaafa86df6669e809313f569',1,'Integer']]]
];
