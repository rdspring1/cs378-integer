var searchData=
[
  ['negative',['negative',['../classInteger.html#a24e88cfdddaf8592b50a13b014820d61',1,'Integer']]]
];
